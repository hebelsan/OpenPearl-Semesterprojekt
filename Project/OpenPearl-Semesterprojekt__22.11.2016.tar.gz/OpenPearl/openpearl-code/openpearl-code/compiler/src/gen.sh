java -jar ~/bin/antlr-4.0-complete.jar -no-listener -visitor SmallPearl.g4

