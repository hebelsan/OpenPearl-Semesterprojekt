/*
 [The "BSD license"]
 Copyright (c) 2014 Rainer Mueller
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:

 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef OCTOPUSDIGTALIN_H_INCLUDED
#define OCTOPUSDIGTALIN_H_INCLUDED
/**
\file

\brief Basic system device for Octopus Digital Input

*/

#include <octopus.h>
#include "Octopus.h"
#include "SystemDationB.h"
#include "Fixed.h"
#include "Signals.h"


namespace pearlrt {

   /**
   \file

   \brief Basic system device for Octopus Digital Input

      This device provides a simple digital input on the
      port bits of the octopus USB board.

   */

   class OctopusDigitalIn: public SystemDationB {

   private:
      const char port;
      const int start, width;
      Octopus * octo;

      void internalDationOpen();
      void internalDationClose();
   public:
      /**
      constructor to create the bit group and set the
      bits to output direction

      \throws IllegalParamSignal in case of init failure

      \param port is the port character 'A', 'B', ...'E'
      \param start is the starting bit number (7..0)
      \param width is the number of bits (1..8)
      */
      OctopusDigitalIn(char port, int start, int width);

      /**
      destructor to remove the bit group
      */
      ~OctopusDigitalIn();

      /**
      Open the OctopusDigitalIn

      \param openParam open parameters if given
      \param idf pointer to IDF-value if given
      \param rstValue pointer to error variable if given 
      \tparam S the length of the filename; the parameter idf is not
            requred for this device
      \throws NotAllowedSignal, if  dation is not closed and rst is not given
      */
      template<size_t S>
      void dationOpen(int openParam=0,
                      Character<S>* idf=0,
                       Fixed<31>* rstValue=0) {
        try {
           if (idf != 0) {
              Log::error("IDF not allowed for Octupus device");
              throw theNotAllowedSignal;
           } 
           if (openParam != 0) {
              Log::error("No open parameters allowed for Octupus device");
              throw theNotAllowedSignal;
           } 
           internalDationOpen();
        } catch (Signal *s) {
            if (rstValue != 0) {
                *rstValue = s->whichRST();
            } else {
              throw;
            }
        }
     } 

      /**
      Close the OctopusDigitalIn

      \param closeParam close parameters if given
      \param rstValue pointer to error variable if given 


      \throws NotAllowedSignal, if  dation is not opened and rst is not given
      */
      void dationClose(int closeParam=0,
                       Fixed<31>* rstValue=0) {
        try {
           if (closeParam != 0) {
              Log::error("No close parameters allowed for Octupus device");
              throw theNotAllowedSignal;
           } 
           internalDationClose();
        } catch (Signal *s) {
            if (rstValue != 0) {
                *rstValue = s->whichRST();
            } else {
              throw;
            }
        }
     } 

      /**
      read  a Bit<width> value from the device

      This method will always throw an exception
      \param data points to the storage location of the data
      \param size denotes the number of bytes of the output data

      \throws IllegalParamSignal, if size != 1, since 1 byte is
                       expected for the Bit<1..8> value
      \throws NotAllowedSignal, if  dation is not opened
      */
      void dationRead(void * data, size_t size);

      /**
      send  a Bit<width> value to the device
      \param data points to the storage location of the data
      \param size denotes the number of bytes of the output data

      \throws notAllowedSignal, if used at all
      */
      void dationWrite(void * data, size_t size);
   };
}
#endif

